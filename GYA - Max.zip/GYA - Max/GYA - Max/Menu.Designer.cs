﻿namespace GYA___Max
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.SeriesButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.moviesButton = new System.Windows.Forms.Button();
            this.quitButton = new System.Windows.Forms.Button();
            this.HelpButton = new System.Windows.Forms.Button();
            this.panelMenu = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // SeriesButton
            // 
            this.SeriesButton.BackColor = System.Drawing.Color.Black;
            this.SeriesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SeriesButton.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.SeriesButton.ForeColor = System.Drawing.Color.Lime;
            this.SeriesButton.Location = new System.Drawing.Point(205, 168);
            this.SeriesButton.Margin = new System.Windows.Forms.Padding(2);
            this.SeriesButton.Name = "SeriesButton";
            this.SeriesButton.Size = new System.Drawing.Size(136, 32);
            this.SeriesButton.TabIndex = 0;
            this.SeriesButton.TabStop = false;
            this.SeriesButton.Text = "Series";
            this.SeriesButton.UseVisualStyleBackColor = false;
            this.SeriesButton.Click += new System.EventHandler(this.SeriesButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(108, 14);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(319, 127);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // moviesButton
            // 
            this.moviesButton.BackColor = System.Drawing.Color.Black;
            this.moviesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.moviesButton.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.moviesButton.ForeColor = System.Drawing.Color.Lime;
            this.moviesButton.Location = new System.Drawing.Point(205, 203);
            this.moviesButton.Margin = new System.Windows.Forms.Padding(2);
            this.moviesButton.Name = "moviesButton";
            this.moviesButton.Size = new System.Drawing.Size(136, 32);
            this.moviesButton.TabIndex = 4;
            this.moviesButton.TabStop = false;
            this.moviesButton.Text = "Movies";
            this.moviesButton.UseVisualStyleBackColor = false;
            this.moviesButton.Click += new System.EventHandler(this.moviesButton_Click);
            // 
            // quitButton
            // 
            this.quitButton.BackColor = System.Drawing.Color.Black;
            this.quitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.quitButton.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.quitButton.ForeColor = System.Drawing.Color.Lime;
            this.quitButton.Location = new System.Drawing.Point(205, 239);
            this.quitButton.Margin = new System.Windows.Forms.Padding(2);
            this.quitButton.Name = "quitButton";
            this.quitButton.Size = new System.Drawing.Size(136, 32);
            this.quitButton.TabIndex = 5;
            this.quitButton.TabStop = false;
            this.quitButton.Text = "Quit";
            this.quitButton.UseVisualStyleBackColor = false;
            this.quitButton.Click += new System.EventHandler(this.quitButton_Click);
            // 
            // HelpButton
            // 
            this.HelpButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.HelpButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.HelpButton.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.HelpButton.ForeColor = System.Drawing.Color.Lime;
            this.HelpButton.Location = new System.Drawing.Point(479, 254);
            this.HelpButton.Margin = new System.Windows.Forms.Padding(2);
            this.HelpButton.Name = "HelpButton";
            this.HelpButton.Size = new System.Drawing.Size(41, 25);
            this.HelpButton.TabIndex = 38;
            this.HelpButton.TabStop = false;
            this.HelpButton.Text = "Help";
            this.HelpButton.UseVisualStyleBackColor = false;
            this.HelpButton.Click += new System.EventHandler(this.HelpButton_Click);
            // 
            // panelMenu
            // 
            this.panelMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelMenu.Controls.Add(this.HelpButton);
            this.panelMenu.Location = new System.Drawing.Point(2, 2);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(529, 288);
            this.panelMenu.TabIndex = 39;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.quitButton);
            this.Controls.Add(this.moviesButton);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.SeriesButton);
            this.Controls.Add(this.panelMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button SeriesButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button moviesButton;
        private System.Windows.Forms.Button quitButton;
        private System.Windows.Forms.Button HelpButton;
        private System.Windows.Forms.Panel panelMenu;
    }
}

