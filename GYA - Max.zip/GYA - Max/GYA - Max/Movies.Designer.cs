﻿namespace GYA___Max
{
    partial class Movies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Movies));
            this.EditButtonMovie = new System.Windows.Forms.Button();
            this.AddMovieButton = new System.Windows.Forms.Button();
            this.line = new System.Windows.Forms.Panel();
            this.ProgressLabelSeries = new System.Windows.Forms.Label();
            this.ScoreLabelSeries = new System.Windows.Forms.Label();
            this.StatusLabelSeries = new System.Windows.Forms.Label();
            this.ratingBoxMovies = new System.Windows.Forms.ComboBox();
            this.StatusBoxMovies = new System.Windows.Forms.ComboBox();
            this.HoursMovies = new System.Windows.Forms.NumericUpDown();
            this.MovieTitleTextBox = new System.Windows.Forms.TextBox();
            this.TitleLabelSeries = new System.Windows.Forms.Label();
            this.MoviesGridView = new System.Windows.Forms.DataGridView();
            this.BackToMenu = new System.Windows.Forms.Button();
            this.RemoveMovieButton = new System.Windows.Forms.Button();
            this.MinMovies = new System.Windows.Forms.NumericUpDown();
            this.panelMovies = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TitleGRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusGRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScoreGRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProgressGRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MinutesGrid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.HoursMovies)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MoviesGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinMovies)).BeginInit();
            this.panelMovies.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // EditButtonMovie
            // 
            this.EditButtonMovie.BackColor = System.Drawing.Color.Black;
            this.EditButtonMovie.Enabled = false;
            this.EditButtonMovie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EditButtonMovie.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.EditButtonMovie.ForeColor = System.Drawing.Color.Lime;
            this.EditButtonMovie.Location = new System.Drawing.Point(102, 187);
            this.EditButtonMovie.Margin = new System.Windows.Forms.Padding(2);
            this.EditButtonMovie.Name = "EditButtonMovie";
            this.EditButtonMovie.Size = new System.Drawing.Size(89, 43);
            this.EditButtonMovie.TabIndex = 37;
            this.EditButtonMovie.TabStop = false;
            this.EditButtonMovie.Text = "Edit";
            this.EditButtonMovie.UseVisualStyleBackColor = false;
            this.EditButtonMovie.Click += new System.EventHandler(this.EditButtonMovie_Click);
            this.EditButtonMovie.Paint += new System.Windows.Forms.PaintEventHandler(this.EditButtonMovie_Paint);
            // 
            // AddMovieButton
            // 
            this.AddMovieButton.BackColor = System.Drawing.Color.Black;
            this.AddMovieButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddMovieButton.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.AddMovieButton.ForeColor = System.Drawing.Color.Lime;
            this.AddMovieButton.Location = new System.Drawing.Point(9, 187);
            this.AddMovieButton.Margin = new System.Windows.Forms.Padding(2);
            this.AddMovieButton.Name = "AddMovieButton";
            this.AddMovieButton.Size = new System.Drawing.Size(89, 43);
            this.AddMovieButton.TabIndex = 36;
            this.AddMovieButton.TabStop = false;
            this.AddMovieButton.Text = "Add";
            this.AddMovieButton.UseVisualStyleBackColor = false;
            this.AddMovieButton.Click += new System.EventHandler(this.AddMovieButton_Click);
            this.AddMovieButton.Paint += new System.Windows.Forms.PaintEventHandler(this.AddMovieButton_Paint);
            // 
            // line
            // 
            this.line.BackColor = System.Drawing.Color.White;
            this.line.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.line.ForeColor = System.Drawing.Color.White;
            this.line.Location = new System.Drawing.Point(10, 90);
            this.line.Margin = new System.Windows.Forms.Padding(2);
            this.line.Name = "line";
            this.line.Size = new System.Drawing.Size(181, 1);
            this.line.TabIndex = 35;
            // 
            // ProgressLabelSeries
            // 
            this.ProgressLabelSeries.AutoSize = true;
            this.ProgressLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ProgressLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.ProgressLabelSeries.ForeColor = System.Drawing.Color.White;
            this.ProgressLabelSeries.Location = new System.Drawing.Point(7, 154);
            this.ProgressLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ProgressLabelSeries.Name = "ProgressLabelSeries";
            this.ProgressLabelSeries.Size = new System.Drawing.Size(49, 13);
            this.ProgressLabelSeries.TabIndex = 34;
            this.ProgressLabelSeries.Text = "Progress";
            // 
            // ScoreLabelSeries
            // 
            this.ScoreLabelSeries.AutoSize = true;
            this.ScoreLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ScoreLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.ScoreLabelSeries.ForeColor = System.Drawing.Color.White;
            this.ScoreLabelSeries.Location = new System.Drawing.Point(7, 129);
            this.ScoreLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ScoreLabelSeries.Name = "ScoreLabelSeries";
            this.ScoreLabelSeries.Size = new System.Drawing.Size(34, 13);
            this.ScoreLabelSeries.TabIndex = 33;
            this.ScoreLabelSeries.Text = "Score";
            // 
            // StatusLabelSeries
            // 
            this.StatusLabelSeries.AutoSize = true;
            this.StatusLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StatusLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.StatusLabelSeries.ForeColor = System.Drawing.Color.White;
            this.StatusLabelSeries.Location = new System.Drawing.Point(7, 102);
            this.StatusLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.StatusLabelSeries.Name = "StatusLabelSeries";
            this.StatusLabelSeries.Size = new System.Drawing.Size(38, 13);
            this.StatusLabelSeries.TabIndex = 32;
            this.StatusLabelSeries.Text = "Status";
            // 
            // ratingBoxMovies
            // 
            this.ratingBoxMovies.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.ratingBoxMovies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ratingBoxMovies.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.ratingBoxMovies.FormattingEnabled = true;
            this.ratingBoxMovies.Items.AddRange(new object[] {
            "Select",
            "10",
            "9",
            "8",
            "7",
            "6",
            "5",
            "4",
            "3",
            "2",
            "1"});
            this.ratingBoxMovies.Location = new System.Drawing.Point(81, 127);
            this.ratingBoxMovies.Margin = new System.Windows.Forms.Padding(2);
            this.ratingBoxMovies.Name = "ratingBoxMovies";
            this.ratingBoxMovies.Size = new System.Drawing.Size(109, 21);
            this.ratingBoxMovies.TabIndex = 31;
            this.ratingBoxMovies.TabStop = false;
            this.ratingBoxMovies.Text = "None";
            // 
            // StatusBoxMovies
            // 
            this.StatusBoxMovies.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.StatusBoxMovies.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StatusBoxMovies.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.StatusBoxMovies.FormattingEnabled = true;
            this.StatusBoxMovies.Items.AddRange(new object[] {
            "Watching",
            "Completed",
            "On-Hold",
            "Dropped",
            "Plan To Watch"});
            this.StatusBoxMovies.Location = new System.Drawing.Point(81, 100);
            this.StatusBoxMovies.Margin = new System.Windows.Forms.Padding(2);
            this.StatusBoxMovies.Name = "StatusBoxMovies";
            this.StatusBoxMovies.Size = new System.Drawing.Size(109, 21);
            this.StatusBoxMovies.TabIndex = 30;
            this.StatusBoxMovies.TabStop = false;
            this.StatusBoxMovies.Text = "Select";
            // 
            // HoursMovies
            // 
            this.HoursMovies.BackColor = System.Drawing.Color.White;
            this.HoursMovies.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.HoursMovies.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.HoursMovies.Location = new System.Drawing.Point(81, 155);
            this.HoursMovies.Margin = new System.Windows.Forms.Padding(2);
            this.HoursMovies.Name = "HoursMovies";
            this.HoursMovies.Size = new System.Drawing.Size(52, 18);
            this.HoursMovies.TabIndex = 29;
            // 
            // MovieTitleTextBox
            // 
            this.MovieTitleTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MovieTitleTextBox.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.MovieTitleTextBox.Location = new System.Drawing.Point(82, 67);
            this.MovieTitleTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.MovieTitleTextBox.Name = "MovieTitleTextBox";
            this.MovieTitleTextBox.Size = new System.Drawing.Size(109, 15);
            this.MovieTitleTextBox.TabIndex = 28;
            this.MovieTitleTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TitleLabelSeries
            // 
            this.TitleLabelSeries.AutoSize = true;
            this.TitleLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TitleLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.TitleLabelSeries.ForeColor = System.Drawing.Color.White;
            this.TitleLabelSeries.Location = new System.Drawing.Point(7, 67);
            this.TitleLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TitleLabelSeries.Name = "TitleLabelSeries";
            this.TitleLabelSeries.Size = new System.Drawing.Size(29, 13);
            this.TitleLabelSeries.TabIndex = 27;
            this.TitleLabelSeries.Text = "Title";
            // 
            // MoviesGridView
            // 
            this.MoviesGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.MoviesGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.MoviesGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MoviesGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TitleGRID,
            this.StatusGRID,
            this.ScoreGRID,
            this.ProgressGRID,
            this.MinutesGrid});
            this.MoviesGridView.GridColor = System.Drawing.Color.Black;
            this.MoviesGridView.Location = new System.Drawing.Point(208, 13);
            this.MoviesGridView.Margin = new System.Windows.Forms.Padding(2);
            this.MoviesGridView.Name = "MoviesGridView";
            this.MoviesGridView.RowHeadersWidth = 62;
            this.MoviesGridView.RowTemplate.Height = 28;
            this.MoviesGridView.Size = new System.Drawing.Size(314, 267);
            this.MoviesGridView.TabIndex = 26;
            this.MoviesGridView.TabStop = false;
            this.MoviesGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.SeriesGridView_CellMouseClick);
            this.MoviesGridView.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.MoviesGridView_CellMouseDoubleClick);
            // 
            // BackToMenu
            // 
            this.BackToMenu.BackColor = System.Drawing.Color.Black;
            this.BackToMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackToMenu.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.BackToMenu.ForeColor = System.Drawing.Color.Lime;
            this.BackToMenu.Location = new System.Drawing.Point(102, 234);
            this.BackToMenu.Margin = new System.Windows.Forms.Padding(2);
            this.BackToMenu.Name = "BackToMenu";
            this.BackToMenu.Size = new System.Drawing.Size(89, 43);
            this.BackToMenu.TabIndex = 25;
            this.BackToMenu.TabStop = false;
            this.BackToMenu.Text = "Main Menu";
            this.BackToMenu.UseVisualStyleBackColor = false;
            this.BackToMenu.Click += new System.EventHandler(this.BackToMenu_Click);
            // 
            // RemoveMovieButton
            // 
            this.RemoveMovieButton.BackColor = System.Drawing.Color.Black;
            this.RemoveMovieButton.Enabled = false;
            this.RemoveMovieButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RemoveMovieButton.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.RemoveMovieButton.ForeColor = System.Drawing.Color.Lime;
            this.RemoveMovieButton.Location = new System.Drawing.Point(9, 234);
            this.RemoveMovieButton.Margin = new System.Windows.Forms.Padding(2);
            this.RemoveMovieButton.Name = "RemoveMovieButton";
            this.RemoveMovieButton.Size = new System.Drawing.Size(89, 43);
            this.RemoveMovieButton.TabIndex = 24;
            this.RemoveMovieButton.TabStop = false;
            this.RemoveMovieButton.Text = "Remove";
            this.RemoveMovieButton.UseVisualStyleBackColor = false;
            this.RemoveMovieButton.Click += new System.EventHandler(this.RemoveMovieButton_Click);
            this.RemoveMovieButton.Paint += new System.Windows.Forms.PaintEventHandler(this.RemoveMovieButton_Paint);
            // 
            // MinMovies
            // 
            this.MinMovies.BackColor = System.Drawing.Color.White;
            this.MinMovies.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.MinMovies.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.MinMovies.Location = new System.Drawing.Point(137, 155);
            this.MinMovies.Margin = new System.Windows.Forms.Padding(2);
            this.MinMovies.Name = "MinMovies";
            this.MinMovies.Size = new System.Drawing.Size(52, 18);
            this.MinMovies.TabIndex = 38;
            // 
            // panelMovies
            // 
            this.panelMovies.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panelMovies.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelMovies.Controls.Add(this.pictureBox1);
            this.panelMovies.Controls.Add(this.MinMovies);
            this.panelMovies.Controls.Add(this.EditButtonMovie);
            this.panelMovies.Controls.Add(this.line);
            this.panelMovies.Controls.Add(this.RemoveMovieButton);
            this.panelMovies.Controls.Add(this.ProgressLabelSeries);
            this.panelMovies.Controls.Add(this.AddMovieButton);
            this.panelMovies.Controls.Add(this.ScoreLabelSeries);
            this.panelMovies.Controls.Add(this.BackToMenu);
            this.panelMovies.Controls.Add(this.StatusLabelSeries);
            this.panelMovies.Controls.Add(this.MovieTitleTextBox);
            this.panelMovies.Controls.Add(this.ratingBoxMovies);
            this.panelMovies.Controls.Add(this.TitleLabelSeries);
            this.panelMovies.Controls.Add(this.StatusBoxMovies);
            this.panelMovies.Controls.Add(this.HoursMovies);
            this.panelMovies.Location = new System.Drawing.Point(2, 2);
            this.panelMovies.Name = "panelMovies";
            this.panelMovies.Size = new System.Drawing.Size(529, 288);
            this.panelMovies.TabIndex = 40;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(194, 46);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 39;
            this.pictureBox1.TabStop = false;
            // 
            // TitleGRID
            // 
            this.TitleGRID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TitleGRID.HeaderText = "Title";
            this.TitleGRID.MinimumWidth = 8;
            this.TitleGRID.Name = "TitleGRID";
            // 
            // StatusGRID
            // 
            this.StatusGRID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.StatusGRID.HeaderText = "Status";
            this.StatusGRID.MinimumWidth = 8;
            this.StatusGRID.Name = "StatusGRID";
            // 
            // ScoreGRID
            // 
            this.ScoreGRID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ScoreGRID.HeaderText = "Score";
            this.ScoreGRID.MinimumWidth = 8;
            this.ScoreGRID.Name = "ScoreGRID";
            // 
            // ProgressGRID
            // 
            this.ProgressGRID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProgressGRID.HeaderText = "Hours";
            this.ProgressGRID.MinimumWidth = 8;
            this.ProgressGRID.Name = "ProgressGRID";
            // 
            // MinutesGrid
            // 
            this.MinutesGrid.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.MinutesGrid.HeaderText = "Minutes";
            this.MinutesGrid.MinimumWidth = 8;
            this.MinutesGrid.Name = "MinutesGrid";
            // 
            // Movies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.MoviesGridView);
            this.Controls.Add(this.panelMovies);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Movies";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Movies";
            this.Load += new System.EventHandler(this.Movies_Load);
            this.Click += new System.EventHandler(this.Movies_Click);
            ((System.ComponentModel.ISupportInitialize)(this.HoursMovies)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MoviesGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MinMovies)).EndInit();
            this.panelMovies.ResumeLayout(false);
            this.panelMovies.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button EditButtonMovie;
        private System.Windows.Forms.Button AddMovieButton;
        private System.Windows.Forms.Panel line;
        private System.Windows.Forms.Label ProgressLabelSeries;
        private System.Windows.Forms.Label ScoreLabelSeries;
        private System.Windows.Forms.Label StatusLabelSeries;
        private System.Windows.Forms.ComboBox ratingBoxMovies;
        private System.Windows.Forms.ComboBox StatusBoxMovies;
        private System.Windows.Forms.NumericUpDown HoursMovies;
        private System.Windows.Forms.TextBox MovieTitleTextBox;
        private System.Windows.Forms.Label TitleLabelSeries;
        public System.Windows.Forms.DataGridView MoviesGridView;
        private System.Windows.Forms.Button BackToMenu;
        private System.Windows.Forms.Button RemoveMovieButton;
        private System.Windows.Forms.NumericUpDown MinMovies;
        private System.Windows.Forms.Panel panelMovies;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleGRID;
        private System.Windows.Forms.DataGridViewTextBoxColumn StatusGRID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScoreGRID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProgressGRID;
        private System.Windows.Forms.DataGridViewTextBoxColumn MinutesGrid;
    }
}