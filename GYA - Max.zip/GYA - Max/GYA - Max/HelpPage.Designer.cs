﻿namespace GYA___Max
{
    partial class HelpPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HelpPage));
            this.panel1 = new System.Windows.Forms.Panel();
            this.howToUseLabel = new System.Windows.Forms.Label();
            this.panelHelp2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TitleLabelSeries = new System.Windows.Forms.Label();
            this.line = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.CloseHelpForm = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel1.SuspendLayout();
            this.panelHelp2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.richTextBox1);
            this.panel1.Controls.Add(this.CloseHelpForm);
            this.panel1.Controls.Add(this.howToUseLabel);
            this.panel1.Controls.Add(this.panelHelp2);
            this.panel1.Controls.Add(this.line);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(529, 288);
            this.panel1.TabIndex = 41;
            // 
            // howToUseLabel
            // 
            this.howToUseLabel.AutoSize = true;
            this.howToUseLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.howToUseLabel.Font = new System.Drawing.Font("UD Digi Kyokasho NP-B", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.howToUseLabel.ForeColor = System.Drawing.Color.Lime;
            this.howToUseLabel.Location = new System.Drawing.Point(314, 35);
            this.howToUseLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.howToUseLabel.Name = "howToUseLabel";
            this.howToUseLabel.Size = new System.Drawing.Size(168, 31);
            this.howToUseLabel.TabIndex = 29;
            this.howToUseLabel.Text = "How to Use";
            // 
            // panelHelp2
            // 
            this.panelHelp2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.panelHelp2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelHelp2.Controls.Add(this.pictureBox2);
            this.panelHelp2.Controls.Add(this.label1);
            this.panelHelp2.Controls.Add(this.TitleLabelSeries);
            this.panelHelp2.Location = new System.Drawing.Point(24, 99);
            this.panelHelp2.Name = "panelHelp2";
            this.panelHelp2.Size = new System.Drawing.Size(203, 176);
            this.panelHelp2.TabIndex = 27;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(47, 61);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(111, 104);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 28;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(44, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Phone: +46735864048";
            // 
            // TitleLabelSeries
            // 
            this.TitleLabelSeries.AutoSize = true;
            this.TitleLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.TitleLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.TitleLabelSeries.ForeColor = System.Drawing.Color.White;
            this.TitleLabelSeries.Location = new System.Drawing.Point(4, 11);
            this.TitleLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TitleLabelSeries.Name = "TitleLabelSeries";
            this.TitleLabelSeries.Size = new System.Drawing.Size(188, 13);
            this.TitleLabelSeries.TabIndex = 13;
            this.TitleLabelSeries.Text = "Email: max.berglund2004@gmail.com";
            // 
            // line
            // 
            this.line.BackColor = System.Drawing.Color.Lime;
            this.line.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.line.ForeColor = System.Drawing.Color.White;
            this.line.Location = new System.Drawing.Point(257, 15);
            this.line.Margin = new System.Windows.Forms.Padding(2);
            this.line.Name = "line";
            this.line.Size = new System.Drawing.Size(1, 260);
            this.line.TabIndex = 26;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(24, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(203, 68);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            // 
            // CloseHelpForm
            // 
            this.CloseHelpForm.FlatAppearance.BorderSize = 0;
            this.CloseHelpForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseHelpForm.ForeColor = System.Drawing.Color.Lime;
            this.CloseHelpForm.Location = new System.Drawing.Point(501, 3);
            this.CloseHelpForm.Name = "CloseHelpForm";
            this.CloseHelpForm.Size = new System.Drawing.Size(25, 25);
            this.CloseHelpForm.TabIndex = 30;
            this.CloseHelpForm.Text = "X";
            this.CloseHelpForm.UseVisualStyleBackColor = true;
            this.CloseHelpForm.Click += new System.EventHandler(this.CloseHelpForm_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richTextBox1.ForeColor = System.Drawing.Color.Lime;
            this.richTextBox1.Location = new System.Drawing.Point(295, 99);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(212, 176);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // HelpPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "HelpPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Help";
            this.Load += new System.EventHandler(this.HelpPage_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelHelp2.ResumeLayout(false);
            this.panelHelp2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label TitleLabelSeries;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel line;
        private System.Windows.Forms.Panel panelHelp2;
        private System.Windows.Forms.Label howToUseLabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CloseHelpForm;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}