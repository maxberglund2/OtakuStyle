﻿namespace GYA___Max
{
    partial class Series
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Series));
            this.BackToMenuS = new System.Windows.Forms.Button();
            this.RemoveSeriesButton = new System.Windows.Forms.Button();
            this.SeriesGridView = new System.Windows.Forms.DataGridView();
            this.TitleGRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusGRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScoreGRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProgressGRID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddSereisButton = new System.Windows.Forms.Button();
            this.line = new System.Windows.Forms.Panel();
            this.ProgressLabelSeries = new System.Windows.Forms.Label();
            this.ScoreLabelSeries = new System.Windows.Forms.Label();
            this.StatusLabelSeries = new System.Windows.Forms.Label();
            this.ratingBox = new System.Windows.Forms.ComboBox();
            this.StatusBoxSeries = new System.Windows.Forms.ComboBox();
            this.ProgressSeriesUD = new System.Windows.Forms.NumericUpDown();
            this.SeriesTitleText = new System.Windows.Forms.TextBox();
            this.TitleLabelSeries = new System.Windows.Forms.Label();
            this.EditButtonSeries = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelSeries = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.SeriesGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProgressSeriesUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BackToMenuS
            // 
            this.BackToMenuS.BackColor = System.Drawing.Color.Black;
            this.BackToMenuS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BackToMenuS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackToMenuS.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.BackToMenuS.ForeColor = System.Drawing.Color.Lime;
            this.BackToMenuS.Location = new System.Drawing.Point(103, 237);
            this.BackToMenuS.Margin = new System.Windows.Forms.Padding(2);
            this.BackToMenuS.Name = "BackToMenuS";
            this.BackToMenuS.Size = new System.Drawing.Size(89, 43);
            this.BackToMenuS.TabIndex = 8;
            this.BackToMenuS.TabStop = false;
            this.BackToMenuS.Text = "Main Menu";
            this.BackToMenuS.UseVisualStyleBackColor = false;
            this.BackToMenuS.Click += new System.EventHandler(this.BackToMenuS_Click);
            // 
            // RemoveSeriesButton
            // 
            this.RemoveSeriesButton.BackColor = System.Drawing.Color.Black;
            this.RemoveSeriesButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RemoveSeriesButton.Enabled = false;
            this.RemoveSeriesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RemoveSeriesButton.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.RemoveSeriesButton.ForeColor = System.Drawing.Color.Lime;
            this.RemoveSeriesButton.Location = new System.Drawing.Point(10, 237);
            this.RemoveSeriesButton.Margin = new System.Windows.Forms.Padding(2);
            this.RemoveSeriesButton.Name = "RemoveSeriesButton";
            this.RemoveSeriesButton.Size = new System.Drawing.Size(89, 43);
            this.RemoveSeriesButton.TabIndex = 7;
            this.RemoveSeriesButton.TabStop = false;
            this.RemoveSeriesButton.Text = "Remove";
            this.RemoveSeriesButton.UseVisualStyleBackColor = false;
            this.RemoveSeriesButton.Click += new System.EventHandler(this.RemoveSeriesButton_Click);
            this.RemoveSeriesButton.Paint += new System.Windows.Forms.PaintEventHandler(this.RemoveSeriesButton_Paint);
            // 
            // SeriesGridView
            // 
            this.SeriesGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.SeriesGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.SeriesGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SeriesGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TitleGRID,
            this.StatusGRID,
            this.ScoreGRID,
            this.ProgressGRID});
            this.SeriesGridView.GridColor = System.Drawing.Color.Black;
            this.SeriesGridView.Location = new System.Drawing.Point(208, 13);
            this.SeriesGridView.Margin = new System.Windows.Forms.Padding(2);
            this.SeriesGridView.Name = "SeriesGridView";
            this.SeriesGridView.RowHeadersWidth = 62;
            this.SeriesGridView.RowTemplate.Height = 28;
            this.SeriesGridView.Size = new System.Drawing.Size(314, 267);
            this.SeriesGridView.TabIndex = 9;
            this.SeriesGridView.TabStop = false;
            this.SeriesGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.SeriesGridView_CellMouseClick);
            this.SeriesGridView.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.SeriesGridView_CellMouseDoubleClick);
            // 
            // TitleGRID
            // 
            this.TitleGRID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TitleGRID.HeaderText = "Title";
            this.TitleGRID.MinimumWidth = 8;
            this.TitleGRID.Name = "TitleGRID";
            // 
            // StatusGRID
            // 
            this.StatusGRID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.StatusGRID.HeaderText = "Status";
            this.StatusGRID.MinimumWidth = 8;
            this.StatusGRID.Name = "StatusGRID";
            // 
            // ScoreGRID
            // 
            this.ScoreGRID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ScoreGRID.HeaderText = "Score";
            this.ScoreGRID.MinimumWidth = 8;
            this.ScoreGRID.Name = "ScoreGRID";
            // 
            // ProgressGRID
            // 
            this.ProgressGRID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProgressGRID.HeaderText = "Progress";
            this.ProgressGRID.MinimumWidth = 8;
            this.ProgressGRID.Name = "ProgressGRID";
            // 
            // AddSereisButton
            // 
            this.AddSereisButton.BackColor = System.Drawing.Color.Black;
            this.AddSereisButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddSereisButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddSereisButton.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.AddSereisButton.ForeColor = System.Drawing.Color.Lime;
            this.AddSereisButton.Location = new System.Drawing.Point(10, 190);
            this.AddSereisButton.Margin = new System.Windows.Forms.Padding(2);
            this.AddSereisButton.Name = "AddSereisButton";
            this.AddSereisButton.Size = new System.Drawing.Size(89, 43);
            this.AddSereisButton.TabIndex = 22;
            this.AddSereisButton.TabStop = false;
            this.AddSereisButton.Text = "Add";
            this.AddSereisButton.UseVisualStyleBackColor = false;
            this.AddSereisButton.Click += new System.EventHandler(this.AddSereisButton_Click);
            this.AddSereisButton.Paint += new System.Windows.Forms.PaintEventHandler(this.AddSereisButton_Paint);
            // 
            // line
            // 
            this.line.BackColor = System.Drawing.Color.White;
            this.line.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.line.ForeColor = System.Drawing.Color.White;
            this.line.Location = new System.Drawing.Point(11, 92);
            this.line.Margin = new System.Windows.Forms.Padding(2);
            this.line.Name = "line";
            this.line.Size = new System.Drawing.Size(181, 1);
            this.line.TabIndex = 21;
            // 
            // ProgressLabelSeries
            // 
            this.ProgressLabelSeries.AutoSize = true;
            this.ProgressLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ProgressLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.ProgressLabelSeries.ForeColor = System.Drawing.Color.White;
            this.ProgressLabelSeries.Location = new System.Drawing.Point(8, 157);
            this.ProgressLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ProgressLabelSeries.Name = "ProgressLabelSeries";
            this.ProgressLabelSeries.Size = new System.Drawing.Size(49, 13);
            this.ProgressLabelSeries.TabIndex = 20;
            this.ProgressLabelSeries.Text = "Progress";
            // 
            // ScoreLabelSeries
            // 
            this.ScoreLabelSeries.AutoSize = true;
            this.ScoreLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ScoreLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.ScoreLabelSeries.ForeColor = System.Drawing.Color.White;
            this.ScoreLabelSeries.Location = new System.Drawing.Point(8, 131);
            this.ScoreLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ScoreLabelSeries.Name = "ScoreLabelSeries";
            this.ScoreLabelSeries.Size = new System.Drawing.Size(34, 13);
            this.ScoreLabelSeries.TabIndex = 19;
            this.ScoreLabelSeries.Text = "Score";
            // 
            // StatusLabelSeries
            // 
            this.StatusLabelSeries.AutoSize = true;
            this.StatusLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StatusLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.StatusLabelSeries.ForeColor = System.Drawing.Color.White;
            this.StatusLabelSeries.Location = new System.Drawing.Point(8, 104);
            this.StatusLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.StatusLabelSeries.Name = "StatusLabelSeries";
            this.StatusLabelSeries.Size = new System.Drawing.Size(38, 13);
            this.StatusLabelSeries.TabIndex = 18;
            this.StatusLabelSeries.Text = "Status";
            // 
            // ratingBox
            // 
            this.ratingBox.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.ratingBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ratingBox.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.ratingBox.FormattingEnabled = true;
            this.ratingBox.Items.AddRange(new object[] {
            "Select",
            "10",
            "9",
            "8",
            "7",
            "6",
            "5",
            "4",
            "3",
            "2",
            "1"});
            this.ratingBox.Location = new System.Drawing.Point(82, 129);
            this.ratingBox.Margin = new System.Windows.Forms.Padding(2);
            this.ratingBox.Name = "ratingBox";
            this.ratingBox.Size = new System.Drawing.Size(109, 21);
            this.ratingBox.TabIndex = 17;
            this.ratingBox.TabStop = false;
            this.ratingBox.Text = "None";
            // 
            // StatusBoxSeries
            // 
            this.StatusBoxSeries.AutoCompleteCustomSource.AddRange(new string[] {
            "None"});
            this.StatusBoxSeries.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StatusBoxSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.StatusBoxSeries.FormattingEnabled = true;
            this.StatusBoxSeries.Items.AddRange(new object[] {
            "Watching",
            "Completed",
            "On-Hold",
            "Dropped",
            "Plan To Watch"});
            this.StatusBoxSeries.Location = new System.Drawing.Point(82, 103);
            this.StatusBoxSeries.Margin = new System.Windows.Forms.Padding(2);
            this.StatusBoxSeries.Name = "StatusBoxSeries";
            this.StatusBoxSeries.Size = new System.Drawing.Size(109, 21);
            this.StatusBoxSeries.TabIndex = 15;
            this.StatusBoxSeries.TabStop = false;
            this.StatusBoxSeries.Text = "Select";
            // 
            // ProgressSeriesUD
            // 
            this.ProgressSeriesUD.BackColor = System.Drawing.Color.White;
            this.ProgressSeriesUD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ProgressSeriesUD.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.ProgressSeriesUD.Location = new System.Drawing.Point(82, 157);
            this.ProgressSeriesUD.Margin = new System.Windows.Forms.Padding(2);
            this.ProgressSeriesUD.Name = "ProgressSeriesUD";
            this.ProgressSeriesUD.Size = new System.Drawing.Size(109, 18);
            this.ProgressSeriesUD.TabIndex = 14;
            // 
            // SeriesTitleText
            // 
            this.SeriesTitleText.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.SeriesTitleText.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.SeriesTitleText.Location = new System.Drawing.Point(83, 69);
            this.SeriesTitleText.Margin = new System.Windows.Forms.Padding(2);
            this.SeriesTitleText.Name = "SeriesTitleText";
            this.SeriesTitleText.Size = new System.Drawing.Size(109, 15);
            this.SeriesTitleText.TabIndex = 13;
            this.SeriesTitleText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TitleLabelSeries
            // 
            this.TitleLabelSeries.AutoSize = true;
            this.TitleLabelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TitleLabelSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.TitleLabelSeries.ForeColor = System.Drawing.Color.White;
            this.TitleLabelSeries.Location = new System.Drawing.Point(8, 69);
            this.TitleLabelSeries.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.TitleLabelSeries.Name = "TitleLabelSeries";
            this.TitleLabelSeries.Size = new System.Drawing.Size(29, 13);
            this.TitleLabelSeries.TabIndex = 12;
            this.TitleLabelSeries.Text = "Title";
            // 
            // EditButtonSeries
            // 
            this.EditButtonSeries.BackColor = System.Drawing.Color.Black;
            this.EditButtonSeries.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EditButtonSeries.Enabled = false;
            this.EditButtonSeries.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EditButtonSeries.Font = new System.Drawing.Font("Yu Gothic UI", 8F);
            this.EditButtonSeries.ForeColor = System.Drawing.Color.Lime;
            this.EditButtonSeries.Location = new System.Drawing.Point(103, 190);
            this.EditButtonSeries.Margin = new System.Windows.Forms.Padding(2);
            this.EditButtonSeries.Name = "EditButtonSeries";
            this.EditButtonSeries.Size = new System.Drawing.Size(89, 43);
            this.EditButtonSeries.TabIndex = 23;
            this.EditButtonSeries.TabStop = false;
            this.EditButtonSeries.Text = "Edit";
            this.EditButtonSeries.UseVisualStyleBackColor = false;
            this.EditButtonSeries.Click += new System.EventHandler(this.editButtonSeries_Click);
            this.EditButtonSeries.Paint += new System.Windows.Forms.PaintEventHandler(this.EditButtonSeries_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(194, 46);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // panelSeries
            // 
            this.panelSeries.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panelSeries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelSeries.Location = new System.Drawing.Point(2, 2);
            this.panelSeries.Name = "panelSeries";
            this.panelSeries.Size = new System.Drawing.Size(529, 288);
            this.panelSeries.TabIndex = 40;
            // 
            // Series
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.EditButtonSeries);
            this.Controls.Add(this.AddSereisButton);
            this.Controls.Add(this.line);
            this.Controls.Add(this.ProgressLabelSeries);
            this.Controls.Add(this.ScoreLabelSeries);
            this.Controls.Add(this.StatusLabelSeries);
            this.Controls.Add(this.ratingBox);
            this.Controls.Add(this.StatusBoxSeries);
            this.Controls.Add(this.ProgressSeriesUD);
            this.Controls.Add(this.SeriesTitleText);
            this.Controls.Add(this.TitleLabelSeries);
            this.Controls.Add(this.SeriesGridView);
            this.Controls.Add(this.BackToMenuS);
            this.Controls.Add(this.RemoveSeriesButton);
            this.Controls.Add(this.panelSeries);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Series";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Series";
            this.Load += new System.EventHandler(this.Series_Load);
            this.Click += new System.EventHandler(this.Series_Click);
            ((System.ComponentModel.ISupportInitialize)(this.SeriesGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProgressSeriesUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BackToMenuS;
        private System.Windows.Forms.Button RemoveSeriesButton;
        public System.Windows.Forms.DataGridView SeriesGridView;
        private System.Windows.Forms.Button AddSereisButton;
        private System.Windows.Forms.Panel line;
        private System.Windows.Forms.Label ProgressLabelSeries;
        private System.Windows.Forms.Label ScoreLabelSeries;
        private System.Windows.Forms.Label StatusLabelSeries;
        private System.Windows.Forms.ComboBox ratingBox;
        private System.Windows.Forms.ComboBox StatusBoxSeries;
        private System.Windows.Forms.NumericUpDown ProgressSeriesUD;
        private System.Windows.Forms.TextBox SeriesTitleText;
        private System.Windows.Forms.Label TitleLabelSeries;
        private System.Windows.Forms.Button EditButtonSeries;
        private System.Windows.Forms.DataGridViewTextBoxColumn TitleGRID;
        private System.Windows.Forms.DataGridViewTextBoxColumn StatusGRID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScoreGRID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProgressGRID;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelSeries;
    }
}